<?php
/**
 * 推荐位相关配置
 *
 */
return [
    'featured_type' => [
        0 => '首页大图推荐位',
        1 => '首页右侧广告位',
        // todo
    ],
];