<?php
/**
 * 地图相关配置文件
 */
return [
    'ak' => '6cbbe4217106227a0b00e1b457510443',
    'baidu_map_url' => 'http://api.map.baidu.com/',
    'geocoder' => 'geocoder/v2/',
    'width' => 400,
    'height' => 300,
    'staticimage' => 'staticimage/v2',
];